package com.assessment.myassessment;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static com.assessment.myassessment.Task1.*;

public class Task1Test {

    private final Task1 task1 = new Task1();

    @Test
    public void getOverdueLoansTestInputListIsNull() {
        System.out.println("Execution started for Testcase getOverdueLoansTestInputListIsNull !!");

        List<LoanAccount> testcase = null;
        List<LoanAccount> outputOfTestCase = task1.getOverdueLoans(testcase);
        int actualSize = outputOfTestCase.size();
        int expectedSize = 0;

        Assertions.assertEquals(expectedSize, actualSize, "getOverdueLoansTestInputListIsNull Failed !!");

        System.out.println("Execution completed for Testcase getOverdueLoansTestInputListIsNull !!");
    }

    @Test
    public void getOverdueLoansTestZeroOutstandingBalance() {
        System.out.println("Execution started for Testcase getOverdueLoansTestZeroOutstandingBalance !!");

        List<LoanAccount> testcase = new ArrayList<>();
        testcase.add(new LoanAccount(
                Date.from(
                        LocalDate.of(2026, 5, 20)
                                .atStartOfDay(ZoneId.systemDefault())
                                .toInstant()
                ),
                0,
                "ACC104"
        ));
        List<LoanAccount> outputOfTestCase = task1.getOverdueLoans(testcase);
        int actualSize = outputOfTestCase.size();
        int expectedSize = 0;

        Assertions.assertEquals(expectedSize, actualSize, "getOverdueLoansTestZeroOutstandingBalance Failed !!");

        System.out.println("Execution completed for Testcase getOverdueLoansTestZeroOutstandingBalance !!");

    }

    @Test
    public void getOverdueLoansTestNegativeOutstandingBalance() {
        System.out.println("Execution started for Testcase getOverdueLoansTestNegativeOutstandingBalance !!");

        List<LoanAccount> testcase = new ArrayList<>();
        testcase.add(new LoanAccount(
                Date.from(
                        LocalDate.of(2026, 5, 20)
                                .atStartOfDay(ZoneId.systemDefault())
                                .toInstant()
                ),
                -50,
                "ACC104"
        ));
        List<LoanAccount> outputOfTestCase = task1.getOverdueLoans(testcase);
        int actualSize = outputOfTestCase.size();
        int expectedSize = 0;

        Assertions.assertEquals(expectedSize, actualSize, "getOverdueLoansTestNegativeOutstandingBalance Failed !!");

        System.out.println("Execution completed for Testcase getOverdueLoansTestNegativeOutstandingBalance !!");
    }

    @Test
    public void getOverdueLoansTestPastAndFutureDueDate() {
        System.out.println("Execution started for Testcase getOverdueLoansTestPastAndFutureDueDate !!");

        List<LoanAccount> testcase = new ArrayList<>();
        testcase.add(new LoanAccount(
                Date.from(
                        LocalDate.of(2026, 5, 1)
                                .atStartOfDay(ZoneId.systemDefault())
                                .toInstant()
                ),
                50000.0,
                "ACC101"
        ));
        testcase.add(new LoanAccount(
                Date.from(
                        LocalDate.of(2026, 5, 20)
                                .atStartOfDay(ZoneId.systemDefault())
                                .toInstant()
                ),
                120000.0,
                "ACC103"
        ));


        List<LoanAccount> outputOfTestCase = task1.getOverdueLoans(testcase);
        int actualSize = outputOfTestCase.size();
        int expectedSize = 1;

        Assertions.assertEquals(expectedSize, actualSize, "getOverdueLoansTestPastAndFutureDueDate Failed !!");

        System.out.println("Execution completed for Testcase getOverdueLoansTestPastAndFutureDueDate !!");
    }

    @Test
    public void getOverdueLoansTestNullDueDate() {
        System.out.println("Execution started for Testcase getOverdueLoansTestNullDueDate !!");

        List<LoanAccount> testcase = new ArrayList<>();
        testcase.add(new LoanAccount(
                null,
                50000.0,
                "ACC101"
        ));
        testcase.add(new LoanAccount(
                null,
                75000.0,
                "ACC102"
        ));

        List<LoanAccount> outputOfTestCase = task1.getOverdueLoans(testcase);
        int actualSize = outputOfTestCase.size();
        int expectedSize = 0;

        Assertions.assertEquals(expectedSize, actualSize, "getOverdueLoansTestNullDueDate Failed !!");

        System.out.println("Execution completed for Testcase getOverdueLoansTestNullDueDate !!");
    }

    @Test
    public void getOverdueLoansTestMixedLoanAccountInput() {
        System.out.println("Execution started for Testcase getOverdueLoansTestMixedLoanAccountInput !!");

        List<LoanAccount> testcase = new ArrayList<>();
        testcase.add(new LoanAccount(
                Date.from(
                        LocalDate.of(2026, 5, 1)
                                .atStartOfDay(ZoneId.systemDefault())
                                .toInstant()
                ),
                50000.0,
                "ACC101"
        ));
        testcase.add(new LoanAccount(
                Date.from(
                        LocalDate.of(2026, 5, 2)
                                .atStartOfDay(ZoneId.systemDefault())
                                .toInstant()
                ),
                75000.0,
                "ACC102"
        ));
        testcase.add(new LoanAccount(
                Date.from(
                        LocalDate.of(2026, 5, 20)
                                .atStartOfDay(ZoneId.systemDefault())
                                .toInstant()
                ),
                120000.0,
                "ACC103"
        ));
        testcase.add(new LoanAccount(
                Date.from(
                        LocalDate.of(2026, 5, 20)
                                .atStartOfDay(ZoneId.systemDefault())
                                .toInstant()
                ),
                -1,
                "ACC104"
        ));
        testcase.add(new LoanAccount(
                Date.from(
                        LocalDate.of(2026, 5, 20)
                                .atStartOfDay(ZoneId.systemDefault())
                                .toInstant()
                ),
                0,
                "ACC105"
        ));
        testcase.add(new LoanAccount(
                Date.from(
                        LocalDate.of(2026, 5, 1)
                                .atStartOfDay(ZoneId.systemDefault())
                                .toInstant()
                ),
                -1,
                "ACC106"
        ));
        testcase.add(new LoanAccount(
                Date.from(
                        LocalDate.of(2026, 5, 1)
                                .atStartOfDay(ZoneId.systemDefault())
                                .toInstant()
                ),
                0,
                "ACC107"
        ));

        List<LoanAccount> outputOfTestCase = task1.getOverdueLoans(testcase);
        int actualSize = outputOfTestCase.size();
        int expectedSize = 2;

        Assertions.assertEquals(expectedSize, actualSize, "getOverdueLoansTestMixedLoanAccountInput Failed !!");

        System.out.println("Execution completed for Testcase getOverdueLoansTestMixedLoanAccountInput !!");
    }

    @AfterAll
    public static void afterAllTestCasesReference() {
        System.out.println("Please refer Task1 class in package com.assessment.myassessment.Task1 for detailed answer !!");
        System.out.println("Task 1 — NullPointerException and control flow fixes (all 3 defects found and fixed)");
    }

}