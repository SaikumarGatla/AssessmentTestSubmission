package com.assessment.myassessment;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.stream.LongStream;

import static com.assessment.myassessment.BankStatementBatchProcessor.*;

public class Task3ORBankStatementBatchProcessorTest {
    private final BankStatementBatchProcessor bankStatementBatchProcessor = new BankStatementBatchProcessor();

    @Test
    public void processAndgetProcessedCountTest() {
        System.out.println("Execution started for Testcase processAndgetProcessedCountTest !!");

        List<StatementRecord> statementRecords = LongStream.rangeClosed(1, 500)
                .mapToObj(longId -> new StatementRecord(longId))
                .toList();
        int expectedSize = statementRecords.size();

        bankStatementBatchProcessor.process(statementRecords);
        int actualSize = bankStatementBatchProcessor.getProcessedCount();
        Assertions.assertEquals(expectedSize, actualSize, "processAndgetProcessedCountTest Failed !!");

        System.out.println("Please refer BankStatementBatchProcessor class in package com.assessment.myassessment.BankStatementBatchProcessor for detailed answer !!");
        System.out.println("Task 3 — Thread-safety: correct fix with explanation of race condition");

        System.out.println("Execution completed for Testcase processAndgetProcessedCountTest !!");
    }

}
