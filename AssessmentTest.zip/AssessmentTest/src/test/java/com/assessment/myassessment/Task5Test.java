package com.assessment.myassessment;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static com.assessment.myassessment.Task5.*;

public class Task5Test {
    private final Task5 task5 = new Task5();

    @Test
    public void task5TestNullInputList() {
        System.out.println("Execution started for Testcase task5TestNullInputList !!");

        List<Document> documents = null;
        task5.validateBatch(documents);

        System.out.println("Execution completed for Testcase task5TestNullInputList !!");
    }

    @Test
    public void task5TestNullElementInsideList() {
        System.out.println("Execution started for Testcase task5TestNullElementInsideList !!");

        Document document = null;
        List<Document> documents = new ArrayList<>();
        documents.add(document);

        task5.validateBatch(documents);
        System.out.println("Execution completed for Testcase task5TestNullElementInsideList !!");
    }


    @Test
    public void task5TestEmptyDocument() {
        System.out.println("Execution started for Testcase task5TestEmptyDocument !!");

        List<Document> documents = List.of(
                new Document("")
        );

        task5.validateBatch(documents);
        System.out.println("Execution completed for Testcase task5TestEmptyDocument !!");
    }

    @Test
    public void task5TestIdealTestCase() {
        System.out.println("Execution started for Testcase task5TestIdealTestCase !!");

        List<Document> documents = List.of(
                new Document("Document Content 1"),
                new Document("Document Content 2"),
                new Document("Document Content 3"),
                new Document("Document Content 4"),
                new Document("Document Content 5")
        );

        task5.validateBatch(documents);
        System.out.println("Execution completed for Testcase task5TestIdealTestCase !!");
    }


}
