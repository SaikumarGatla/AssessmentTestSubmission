package com.assessment.myassessment;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static com.assessment.myassessment.Task2Analysis.*;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class Task2AnalysisTest {

    private final Task2Analysis task2Analysis = new Task2Analysis();

    @Test
    public void reproduceConcurrentModificationExceptionTest() {
        System.out.println("Execution started for Testcase reproduceConcurrentModificationExceptionTest !!");

        List<Transaction> transactions = new ArrayList<>();
        transactions.add(new Transaction(1001L, true));
        transactions.add(new Transaction(1002L, false));
        transactions.add(new Transaction(1003L, true));
        transactions.add(new Transaction(1004L, true));
        transactions.add(new Transaction(1005L, false));

        RuntimeException runtimeException = assertThrows(RuntimeException.class, () -> {
            task2Analysis.reproduceConcurrentModificationException(transactions);
        });

        System.out.println("Task 2 — Root cause analysis: correct explanation + code pattern + fix");
        System.out.println(runtimeException.getClass() + " is reproduced !!");
        System.out.println("Please refer Task2Analysis class in package com.assessment.myassessment.Task2Analysis for detailed answer of following questions !!");
        System.out.println("" +
                "1.\tWhat is the exact cause of ConcurrentModificationException in Java?\n" +
                "2.\tWhat code pattern at line 142 most likely triggered this error?\n" +
                "3.\tProvide the minimal code change (one or two lines) that resolves this safely.\n");
        System.out.println("Execution completed for Testcase reproduceConcurrentModificationExceptionTest !!");
    }

}
