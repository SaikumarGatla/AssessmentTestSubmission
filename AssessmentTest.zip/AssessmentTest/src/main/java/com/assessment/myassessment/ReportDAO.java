package com.assessment.myassessment;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ReportDAO {

    private DataSource dataSource;

    public List<ReportEntry> fetchMonthlyReport(String accountId, int month, int year)
            throws SQLException {

        // FIX: Use try-with-resources to ensure Connection, PreparedStatement, and ResultSet are closed automatically,
        //      when the block exits — whether normally or via an exception.
        //      This prevents connection pool exhaustion/resource leaks.
        //
        //      Resources are closed in reverse order automatically(LIFO):
        //      ResultSet -> PreparedStatement -> Connection
        //      , which matches the required order from the task.
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "SELECT * FROM report_entries " +
                             "WHERE account_id = ? AND MONTH(entry_date) = ? " +
                             "AND YEAR(entry_date) = ?"
             )) {

            ps.setString(1, accountId);
            ps.setInt(2, month);
            ps.setInt(3, year);

            // FIX: ResultSet is also declared inside try-with-resources
            //      so it is closed before PreparedStatement is closed.
            try (ResultSet rs = ps.executeQuery()) {
                List<ReportEntry> entries = new ArrayList<>();
                while (rs.next()) {
                    entries.add(mapRow(rs));
                }
                return entries;     // conn, ps, rs are never closed
            }
        }
        // FIX: conn, ps, rs are now guaranteed to be closed — no leak.
    }

    // ---------------------------------------------------------------------------
    //  ReportEntry mapRow(ResultSet rs) and static class ReportEntry added so the file compiles stand-alone
    // ---------------------------------------------------------------------------
    private ReportEntry mapRow(ResultSet rs) throws SQLException {
        return new ReportEntry(); // original logic — unchanged
    }

    static class ReportEntry {}
}