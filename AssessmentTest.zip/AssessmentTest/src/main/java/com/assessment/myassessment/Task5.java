package com.assessment.myassessment;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class Task5 {

    // FIX: Declare a proper SLF4J logger.(issues 1 & 4)
    //     Replaces e.printStackTrace() with structured, level-appropriate log statements.
    private static final Logger logger = LoggerFactory.getLogger(Task5.class);

    public ValidationResult validate(Document doc) {
        try {
            if (doc == null) {
                throw new RuntimeException("Document is null");
            }
            String content = doc.extractContent();
            if (content == null || content.isEmpty()) {
                throw new RuntimeException("Empty content");
            }
            return runValidationRules(content);

        } catch (Exception e) {
            // FIX: (issue 1)Log exception message at WARN/ERROR level instead of printing stack trace
            logger.warn("\nValidation failed: {}", e.getMessage());       // issue 1

            // FIX: (issue 2)Return a failure ValidationResult instead of null to avoid NullPointerException at method call
            return new ValidationResult(false, e.getMessage());     // issue 2
        }
    }

    public void validateBatch(List<Document> docs) {
        // FIX: Null-safe check prevents NullPointerException if input List<Document> docs is null
        if(docs == null) return;

        for (Document doc : docs) {
            try {
                ValidationResult r = validate(doc);
                // FIX: (issue 3) validate() no longer returns null (issue 2 fixed),
                // Null-safe check prevents NullPointerException if validate(doc) call return null.
                // But we still guard explicitly so the method is robust against any future change that reintroduces null returns.
                if (r != null && r.isValid()) {
                    saveResult(r);      // issue 3
                }
            } catch (Exception e) {
                // silent — swallowed completely    // issue 4

                // FIX: (issue 4) Log the error so it isn't swallowed
                // Used logger.error(),
                // so the support team can diagnose failures without stack-trace flooding.
                logger.error("\nDocument Batch item processing failed", e);
            }
        }
    }

    // ---------------------------------------------------------------------------
    // ValidationResult runValidationRules(String content),
    // void saveResult(ValidationResult validationResult),
    // static class Document and static class ValidationResult
    // are added explicitly so the file compiles stand-alone (do not modify per task rules)
    // ---------------------------------------------------------------------------
    private ValidationResult runValidationRules(String content) {
        return ValidationResult.valid(); // original logic — unchanged
    }

    private void saveResult(ValidationResult validationResult) {
        // original logic — unchanged
    }

    // Minimal supporting types used/defined just for testing purpose
    public static class Document {
        private String content;

        public Document(String content) {
            this.content = content;
        }

        public String extractContent() { return this.content; }
    }

    public static class ValidationResult {
        private final boolean valid;
        private final String reason;

        private ValidationResult(boolean valid, String reason) {
            this.valid = valid;
            this.reason = reason;
        }

        public static ValidationResult valid()                  { return new ValidationResult(true,  null); }
        public boolean isValid()                                 { return valid; }
    }

}