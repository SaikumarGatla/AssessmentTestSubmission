package com.assessment.myassessment;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public class BankStatementBatchProcessor {
    // FIX: Making necessary changes considering multi-threaded environment (with thread pool of 10)
    // int is not thread-safe for concurrent increment operations.
    // Hence, AtomicInteger is used to make increment operations on processedCount thread-safe.

    // In multi-threaded execution, multiple threads can read/update/write the same value simultaneously,
    // causing a race condition and lost updates.
    // The increment operation is a critical section because shared mutable state is being modified concurrently.

    // Multiple threads are trying to update processedCount simultaneously which was resulting in a race condition.
    // The statement processedCount++ is not atomic because it involves:
    // 1. Read current value
    // 2. Increment value
    // 3. Write updated value
    // If two threads execute this critical section at the same time,
    // some increments are lost, resulting in inconsistent processedCount(i.e. fewer records than what were actually processed).
    private final AtomicInteger processedCount = new AtomicInteger(0);

    public void process(List<StatementRecord> records) {
        ExecutorService executor = Executors.newFixedThreadPool(10);

        for (StatementRecord record : records) {
            executor.submit(() -> {
                processRecord(record);

                // FIX: AtomicInteger provides thread-safe atomic increment operation
                // and prevents lost updates in concurrent environment.

                // FIX: incrementAndGet() performs atomic increment safely
                // without lost updates in concurrent execution.
                processedCount.incrementAndGet();       // <-- inconsistent in production
            });
        }

        executor.shutdown();

        // Added try-catch block because executor.awaitTermination(5, TimeUnit.MINUTES);  throws InterruptedException which needs to be handled or else code won't compile hence it was necessary for Assessment.
        // I did not change the method signature of process(List<StatementRecord>) by adding throws InterruptedException, because it would result in change of method signature.
        try {
            executor.awaitTermination(5, TimeUnit.MINUTES);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    public int getProcessedCount() {
        // return actual integer value from AtomicInteger
        return processedCount.get();
    }

    // ---------------------------------------------------------------------------
    // void processRecord(StatementRecord record), static class StatementRecord added explicitly so the file compiles stand-alone
    // ---------------------------------------------------------------------------

    // Added this method by guessing because it was not given in Assessment Code snippet. Without then method void processRecord(StatementRecord record) the code won't compile hence it was necessary for Assessment.
    private void processRecord(StatementRecord record) {
        // The logic of processing StatementRecord record comes here.
    }

    public static class StatementRecord {
        private long statementRecordId;

        public StatementRecord(long statementRecordId) {
            this.statementRecordId = statementRecordId;
        }

        public long getStatementRecordId() {
            return statementRecordId;
        }
    }
}