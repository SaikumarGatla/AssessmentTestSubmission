package com.assessment.myassessment;

public class Task3 {
//    Please refer to BankStatementBatchProcessor class in org.assessment.myassessment of this Maven project
//    For Task 3
//    Thread-safety: correct fix with explanation of race condition
    public static void main(String[] args) {
        System.out.println("Please refer to BankStatementBatchProcessor class in org.assessment.myassessment of this Maven project");
        System.out.println("For Task 3");
        System.out.println("Thread-safety: correct fix with explanation of race condition");
    }
}