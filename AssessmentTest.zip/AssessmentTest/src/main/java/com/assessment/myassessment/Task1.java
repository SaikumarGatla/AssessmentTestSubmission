package com.assessment.myassessment;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Task1 {
    public List<LoanAccount> getOverdueLoans(List<LoanAccount> accounts) {
        // FIX: Initialize result list to a new ArrayList instead of null to avoid NullPointerException on .add() method call.
        // Now the result list exists and accounts can safely be added inside loop
        List<LoanAccount> result = new ArrayList<>();

        // FIX: Prevent NullPointerException when input accounts list itself is null
        if (accounts == null) {
            return result;
        }

        for (LoanAccount account : accounts) {
            // FIX: Prevent NullPointerException for:
            // null account objects
            // and
            // null dueDate field of LoanAccount account object
            if (account != null && account.getDueDate() != null) {

                if (account.getDueDate().before(new Date())) {
                    if (account.getOutstandingBalance() > 0) {
                        result.add(account);
                    }
                }

            }
        }
        // Suggestion:
        // Instead of account.getDueDate().before(new Date()) inside the loop
        // Define a variable like Date currentDate = new Date(); outside loop

        // Reason for suggestion:
        // Reason 1:
        // If new Date() is called repeatedly inside the loop:
        // every iteration creates a slightly different timestamp.
        // Example:
        // Iteration	Time
        // 1	        10:00:00.001
        // 2	        10:00:00.005
        // 3	        10:00:00.010
        // This can create inconsistent comparisons for edge-case due dates.

        // Reason 2:
        // Without variable: new Date() creates a new object every iteration.
        // With variable: Date currentDate = new Date(); only one object is created.
        // Less object creation = cleaner and slightly more efficient.

        return result;
    }

    // LoanAccount fields:
    // Date dueDate          — may be null for restructured accounts
    // double outstandingBalance
    // String accountId      — always non-null

    // ---------------------------------------------------------------------------
    // public static class LoanAccount added explicitly so the file compiles stand-alone
    // ---------------------------------------------------------------------------
    public static class LoanAccount {
        private Date dueDate;
        private double outstandingBalance;
        private String accountId;

        public LoanAccount(Date dueDate, double outstandingBalance, String accountId) {
            this.dueDate = dueDate;
            this.outstandingBalance = outstandingBalance;
            this.accountId = accountId;
        }

        public Date getDueDate()            { return dueDate; }
        public double getOutstandingBalance(){ return outstandingBalance; }
        public String getAccountId()        { return accountId; }
    }

}