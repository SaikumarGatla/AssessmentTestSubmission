package com.assessment.myassessment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyassessmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyassessmentApplication.class, args);
	}

}
