package com.assessment.myassessment;

public class Task4 {
//    Please refer to ReportDAO class in org.assessment.myassessment of this Maven project
//    For Task 4
//    Resource leak: correct try-with-resources with proper closure order
    public static void main(String[] args) {
        System.out.println("Please refer to ReportDAO class in org.assessment.myassessment of this Maven project");
        System.out.println("For Task 4");
        System.out.println("Resource leak: correct try-with-resources with proper closure order");
    }
}